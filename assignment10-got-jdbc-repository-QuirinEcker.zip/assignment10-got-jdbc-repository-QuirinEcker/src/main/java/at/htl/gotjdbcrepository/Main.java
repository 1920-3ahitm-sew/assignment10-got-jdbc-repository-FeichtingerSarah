package at.htl.gotjdbcrepository;

public class Main {

    public static void main(String[] args) {
        System.out.println("Please use the unit-tests");
    }

}
